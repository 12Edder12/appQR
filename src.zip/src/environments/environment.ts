export const environment = {
  PAGE_SIZE: 6
};
